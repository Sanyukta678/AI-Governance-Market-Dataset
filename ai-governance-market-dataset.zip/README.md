# AI Governance Market — Dataset

This dataset contains structured metadata and derived summaries based on the public landing page of the "AI Governance Market" report (report code: 3562) by Next Move Strategy Consulting.

It includes only publicly visible information reorganized into research-friendly files. It does NOT include the paid PDF or proprietary content.
